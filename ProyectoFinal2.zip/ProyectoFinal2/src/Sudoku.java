import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
/* Proyecto Final para P.O.O Primavera 2014
 * por Sean Thomas Burger Flores ID 146857
 * Linjul Casta�eda ID 149154  , Luz Eli Pelcastre ID 148249  y  Dxhunaxhi Del Carmen Chavez Mendez ID  1483892
 */

class Sudoku extends JFrame implements ActionListener 
{

//Declaro 
// el atributo nivel y los elementos incluidos dentro de mi frame : los matriz de botones 9x9 
//Declaro mi panel y los subpaneles , declaro mis menus , y llamo a sudoku2 mi sudoku.
private int nivel;
private JButton botones[][] = new JButton[9][9];
private	JPanel panel,b1 ,b2,b3,b4,b5,b6,b7,b8,b9;
private JMenu miMenu,miMenu2,miMenu3;

Sudoku2 miSudoku;
	
	//Inicia Main
	public static void main(String[] args) {
       Sudoku frame = new Sudoku();
       frame.setVisible(true);
    }//Fin de Main , creo un frame y lo hago visible.
	
	//Inicia Sudoku(9
	public Sudoku(){
		//Declaro y creo mi container
	int i,j;
	Container contentPane;
	contentPane=getContentPane();
	contentPane.setLayout(null);

	miSudoku = new Sudoku2();
// Le pongo  titulo y tama�o 	
	setTitle("Sudoku P.O.O");
	setSize(500,500);
	setLocation(10,10);
	setResizable(false);
	//metodos para crear los menus
	crearMenu();
	crearMenu2();
	crearMenu3();
	//Creo un JMenuBar y a�ado mis menus
	JMenuBar menuBar = new JMenuBar(); 
	setJMenuBar(menuBar);  
    menuBar.add(miMenu);
    menuBar.add(miMenu2);
    menuBar.add(miMenu3);
   //////   
//Creo un GridLayout de 3x3 me permite genera mis botones con un formato determinado
   //, junto con el panel al cual de pongo su ubicaci�n , tama�o y bordes    	
	GridLayout matriz = new GridLayout(3,3);
	panel = new JPanel(matriz);
	panel.setLocation(10,10);
	panel.setSize(400,400);
	panel.setBorder(BorderFactory.createLineBorder(Color.black));
	//Creo mis subpaneles de 3x3 y les pongo borde con color
	b1= new JPanel(new GridLayout(3,3)); 
	b1.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
	b2= new JPanel(new GridLayout(3,3));
	b2.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
	b3= new JPanel(new GridLayout(3,3));
	b3.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
	b4= new JPanel(new GridLayout(3,3));
	b4.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
	b5= new JPanel(new GridLayout(3,3));
	b5.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
	b6= new JPanel(new GridLayout(3,3));
	b6.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
	b7= new JPanel(new GridLayout(3,3));
	b7.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
	b8= new JPanel(new GridLayout(3,3));
	b8.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
	b9= new JPanel(new GridLayout(3,3));
	b9.setBorder (BorderFactory.createLineBorder (Color.cyan));
	
//Ahora inicio una serie de fors anidados para a�adirle botones a mis subpaneles ; a los botones les pongo color y los a�ado
	// al ActionListener
	
	for(i=0;i<3;i++)
	{
		for (j=0;j<3;j++) {
			botones[i][j]= new JButton();
			botones[i][j].setBackground(Color.white);
			botones[i][j].addActionListener(this);
			this.b1.add(botones[i][j]);
			}
		for(j=3;j<6;j++){
			botones[i][j] = new JButton();
			botones[i][j].setBackground(Color.white);
			botones[i][j].addActionListener(this);
			this.b2.add(botones[i][j]) ;
			
		}
		for (j=6;j<9;j++) {
			botones[i][j] = new JButton();
			botones[i][j].setBackground(Color.white);
			botones[i][j].addActionListener(this);
			this.b3.add(botones[i][j]) ;
		}
	}
		for (i=3;i<6;i++){
			for(j=0;j<3;j++){
				botones[i][j] = new JButton();
				botones[i][j].setBackground(Color.white);
				botones[i][j].addActionListener(this);
				this.b4.add(botones[i][j]) ;
			}
			
			for(j=3;j<6;j++){
				botones[i][j] = new JButton();
				botones[i][j].setBackground(Color.white);
				botones[i][j].addActionListener(this);
				this.b5.add(botones[i][j]) ;
		}
			for (j=6;j<9;j++) {
				botones[i][j] = new JButton();
				botones[i][j].setBackground(Color.white);
				botones[i][j].addActionListener(this);
				this.b6.add(botones[i][j]) ;
			}
		}
			 
			for(i=6;i<9;i++){
				for(j=0;j<3;j++){
					botones[i][j] = new JButton();
					botones[i][j].setBackground(Color.white);
					botones[i][j].addActionListener(this);
					this.b7.add(botones[i][j]) ;
				}
				
				for(j=3;j<6;j++){
					botones[i][j] = new JButton();
					botones[i][j].setBackground(Color.white);
					botones[i][j].addActionListener(this);
					this.b8.add(botones[i][j]) ;
			}
				for (j=6;j<9;j++) {
					botones[i][j] = new JButton();
					botones[i][j].setBackground(Color.white);
					botones[i][j].addActionListener(this);
					this.b9.add(botones[i][j]) ;
				}
				
			} // A�ado mis subpaneles a mi panel
			panel.add(b1);
			panel.add(b2);
			panel.add(b3);
			panel.add(b4);
			panel.add(b5);
			panel.add(b6);
			panel.add(b7);
			panel.add(b8);
			panel.add(b9);
			contentPane.add((panel));
			//a�ado mi panel a mi contentPane
			
		}
			
			
			
// Inicia ActionPerformed
		public void actionPerformed(ActionEvent e)
			{   //declaro varibles locales
				int val,i,j,fin;
				JButton b;
				String opcion;
				//Declaro mis variables locales y a indicar las acciones de las opciones de los menus y de los botones
				if(e.getSource() instanceof JButton)
				{   // ese if evita que los botones sean editados a menos que se haya seleccionado un nivel
					if(nivel == 0)
							JOptionPane.showMessageDialog(null,"No has seleccionado aun tu nivel.");
					else
					{ //Aqu� lo que hago es que primero el usuario tiene que elegir un nivel previo a poder editar las casillas
						try
						{  //Los valores a entrar son n�meros enteros entre 1 y 9 . Si se pone otro valor saldra un mensaje
							val = Integer.parseInt(JOptionPane.showInputDialog(null, "Escribe un n�mero entre 1 y 9"));
							if(val>0 && val <10)
							{
								b = (JButton) e.getSource();
								b.setText(""+val);
								fin =0;
								i=j=0;
								for(i=0;i<9 && fin==0;i++)
									for(j=0;j<9 && fin==0;j++)
									{
										if(botones[i][j]==b)
											fin=1;
									}
								miSudoku.matriz[i][j] = val;
								
							} else {  //los valores deben de ser enteros y del rango 1-9
								throw new Exception("Valor fuera de rango!");
							}
				
						}
						catch (NumberFormatException ex){
							JOptionPane.showMessageDialog(null,"Error: lo que tecleaste no fue un entero.");
						}
						catch (Exception ex) {
							JOptionPane.showMessageDialog(null,"Error: "+ex.getMessage());
						}
					}
				} else {
					opcion = e.getActionCommand();
					// Al presionar salir , cierra la ventana y acaba con el programa
					if(opcion.equals("Salir") )
						System.exit(0);
					else{
						if(opcion.equals("Autores"))
                 	   { //Unicamente muestra los autores de este proyecto en un mensaje
                 		   JOptionPane.showMessageDialog(null," Sean Thomas Burger Flores ID 146857 \n Linjul Casta�eda ID 149154  ,\n Luz Eli Pelcastre ID 148249\n  y  Dxhunaxhi Del Carmen Chavez ID  1483892");
                 	   }
						else{
							if(opcion.equals("Instrucciones"))
							{ //Despliega las instrucciones sobre como jugar un sudoku
								JOptionPane.showMessageDialog(null,"Sudoku se juega en una cuadr�cula de 9x9, subdividida en cuadrantes 3x3 \n"
										+ "Sudoku comienza con algunas casillas ya rellenas por n�meros\n "
										+ "se rellenan todas las casillas vac�as con n�meros del 1 al 9 \n"
										+ "un n�mero solamente puede aparecer una vez en cada fila, columna y cuadrantes \n");
							}
							else{ //Al dar clic en Nivel 1 inicia un ciclo for para generar 40 enteros aleatorios
								if(opcion.equals("Nivel 1"))
								{
									nivel = 1;
									miSudoku.generar(nivel);
									for(i=0;i<9;i++){ 
										for(j=0;j<9;j++){
											if(miSudoku.matriz[i][j] != 0)
											{
												botones[i][j].setText(""+miSudoku.matriz[i][j]);
												botones[i][j].removeActionListener(this);
											}
											else
												botones[i][j].setText("");
											   botones[i][j].addActionListener(this);
										}
									}
								}
								else if(opcion.equals("Nivel 2")) //Igual que al presionar Nivel 1 solo que aqu� solo se generean 30 
								{
									nivel = 2;
									miSudoku.generar(nivel);
									for(i=0;i<9;i++){
										for(j=0;j<9;j++){
											if(miSudoku.matriz[i][j] != 0)
											{
												botones[i][j].setText(""+miSudoku.matriz[i][j]);
												botones[i][j].removeActionListener(this);
											}
											else
												botones[i][j].setText("");
											botones[i][j].addActionListener(this);
											  
										}
									} 
								} else if(opcion.equals("Nivel 3")) //Solamente genera 20 enteros
								{
									nivel = 3;
									miSudoku.generar(nivel);
									for(i=0;i<9;i++){
										for(j=0;j<9;j++){
											if(miSudoku.matriz[i][j] != 0)
											{
												botones[i][j].setText(""+miSudoku.matriz[i][j]);
												botones[i][j].removeActionListener(this);
											}
											else
												botones[i][j].setText("");
											botones[i][j].addActionListener(this);
											
										}
									}
								} 
							}
							if(opcion.equals("checar"))
							{  //dos boolean y un string 
								boolean r=true, lleno=true;
								String msg="";
								for(i=0;i<9;i++) //inicio el for para revisar mi matriz 
								{
									r=miSudoku.revisaColumna2(i); //invoco al metodo de miSudoku revisaColumna
									if(r==false)
										msg = msg+" en columna "+i;
								}
								for(i=0;i<9;i++) 
								{
									r=miSudoku.revisaFila2(i);
									if(r==false)
										msg = msg+ " en fila "+i; //hago lo mismo pero con las filas 
								} //aqu� solo checo que no haya n�meros repetidos
								for(i=0;i<9;i++)
									for(j=0;j<9;j++)
										if(miSudoku.matriz[i][j]==0)
											lleno=false; 
								if(r==false);
									JOptionPane.showMessageDialog(null, "Error:"+msg +"\n no has terminado");
								
									if(lleno == true)
									JOptionPane.showMessageDialog(null,"Feliciades has terminado el sudoku \n tus n�meros estan bien");
									//El segundo for revisa que la matriz este llena.
									}
							
						} 
						
					}
				}
			}
		//-------------------------------------------------
//      Metodos Privados
//
// private void   crearMenu ()
// private void crearMenu2()		
// private void crearMenu3()         
//
//------------------------------------------------

    /**
     * Creamos el menu y le a�adimos sus items
     *
     */
    private void crearMenu( ) {
        JMenuItem    item; 

        miMenu = new JMenu("Juego"); // Le ponemos un nombre al JMenu
        
        item = new JMenuItem("checar");  // Revisa la matriz para ver si el sudoku esta resuelto o no
        item.addActionListener( this );
        miMenu.add( item );

        miMenu.addSeparator();           //a�adimos una barra horizontal separadora

        item = new JMenuItem("Salir");       //Salir
        item.addActionListener( this );
        miMenu.add( item );
        
    }
    
    private void crearMenu2( ) {
        JMenuItem    item; 

        miMenu2 = new JMenu("Niveles");
        
        item = new JMenuItem("Nivel 1");    //Nivel 1
        item.addActionListener( this );
        miMenu2.add( item );

        item = new JMenuItem("Nivel 2");    //Nivel 2
        item.addActionListener( this );
        miMenu2.add( item );

          

               
        item = new JMenuItem("Nivel 3"); //Nivel 3
        item.addActionListener( this );
        miMenu2.add( item );

        miMenu2.addSeparator();           //a�adimos una barra horizontal separadora

       }
    
    private void crearMenu3( ) {
        JMenuItem    item; 

        miMenu3 = new JMenu("Ayuda"); // Le ponemos nombre al JMenu
        
        item = new JMenuItem("Instrucciones");    //Menu Item Instrucciones
        item.addActionListener( this );
        miMenu3.add( item );
        
        item = new JMenuItem("Autores"); // JMenuItem Autores
        item.addActionListener (this);
        miMenu3.add(item);

        

        miMenu3.addSeparator();           //a�adimos una barra horizontal separadora

       }
    



}	

// Fin de Sudoku class