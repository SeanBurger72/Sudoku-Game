
public class Sudoku2 {
	 int matriz[][];
	 
	 public Sudoku2(){
		 matriz=new int [9][9];
	 }
	
	
		public void generar(int nivel){

			int i,j,w,q,cont,X;
			
			X=0;
			cont =0;
			// asigna n�mero de valores de acuerdo al nivel
			if(nivel ==1)
				nivel = 30;
			else if(nivel==2)
				nivel = 22;
			else nivel = 15;
			
			 for (i=0; i<=8;i++)// i = columnas
				 for(j=0;j<=8;j++) // j = renglones/filas
					 matriz[i][j]=0; //matriz compuesta de columnas y filas. Posicion 
			 do{
				 w=(int)(Math.random()*(8));//fila    numeros
				 q=(int)(Math.random()*(8));//columna
						 
				 if(matriz[w][q]==0)  // empieza en blanco
				 {
					 X= (int) (Math.random()*8+1); //inicio X , genera un numero aleatorio lo multiplica por 8 y le suma 1
					 System.out.println("X (en genera) ="+X+" en coordenadas [ren][col] "+w+" "+q); //Imprime en consola
					 // como genera los numeros 
					 matriz[w][q]= X;
					 revisaFila(w);
					 revisaColumna(q);
					 revisaArea(w,q);
					 
					 //if(revisaFila(w,X)==true && revisaColumna(q,X)==true && revisaArea(w,q,X)==true)
					 //{
						 cont++;
						 System.out.println("Contador se incrementa a "+cont);
					 //}
				 }
			 }while(cont<nivel);
		}

		public void revisaFila(int j)
		{
			int X,caux,i,k;
			 
			X=0;
			for(k=1;k<=9;k++) //buscar cada valor del 1 al 9
			{
				caux=0;
				
				for (i=0;i<=8;i++) // por cada columna i en el rengl�n j
				{	 
						 //Revisa las filas mientras se generan los n�meros 
						if(matriz[j][i]==k)
						{	 
							caux++;	 //contador que incrementa
							if(caux > 1) // mientras el contador sea mayor a 1
							{
								System.out.println("dato repetido en fila");
								X=(int)(Math.random()*8+1);
								System.out.println("Nuevo valor X "+X);
								matriz[j][i]=X;
								revisaFila(j);
								caux=0;
							}
						}		 				
				}
			}
		}
// Revisa mientras juegas
		public boolean revisaFila2(int j)
		{
			int caux,i,num;
			boolean salida = true;
			
			for(num=1;num<=9;num++)
			{
			caux=0;
				for (i=0;i<=8;i++) // por cada columna i en el rengl�n j
				{	 
						if(matriz[j][i]==num)
						{	 
							caux++;	 
							if(caux > 1)
							{
								System.out.println("Dato en "+j+i+" es "+matriz[j][i]+" y igual a "+num);
								salida = false;
							} // Para revisar que se repita , cuantas veces se repite un n�mero en una fila
						}		 				
				}
			}
			return salida; //Regresa
		}

		
		public void revisaColumna(int i)
		{
			int X, caux,j,k;
			X=0;
			for(k=1;k<=9;k++)
			{
				 caux=0;
				 for (j=0;j<9;j++)  //Revisa al generar niveles
				 {
						 if(matriz[j][i]==k)
						 {
							 caux++;
							if(caux > 1)
							{
								System.out.println("dato repetido en columna");
								X=(int)(Math.random()*8+1);
								System.out.println("Nuevo valor X "+X);
									matriz[j][i]=X;
									revisaFila(j);
									revisaColumna(i); 
									caux=0;
							}
						 }
				 }
			}
		}
//Para cuando juegas
		public boolean revisaColumna2(int i)
		{
			int caux,j,num;
			boolean salida = true;

			
			for(num=1;num<=9;num++)
			{
			caux=0;
				for (j=0;j<=8;j++) // por cada columna i en el rengl�n j
				{	 
						if(matriz[j][i]==num)
						{	 
							caux++;	 
							if(caux > 1)
							{
								System.out.println("Dato en "+j+i+" es "+matriz[j][i]+" y igual a "+num);
								salida = false;
							}
						}		 				
				}
			}
			return salida;		}

		
		public boolean revisaArea(int ren, int col, int num){
			int caux,i,j,cuad,x1,x2,y1,y2;
			boolean salida=true;
			//Cuadrantes son declarados
			x1=x2=y1=y2=0;
			
			if(ren >=0 && ren <=2)
			{
				if(col>=0 && col <= 2)
					cuad = 1;
				else if(col>=3 && col <= 5)
					cuad = 2;
				else cuad = 3;
			} else {
				if(ren >= 3 && ren <= 5)
				{
					if(col>=0 && col <= 2)
						cuad = 4;
					else if(col>=3 && col <= 5)
						cuad = 5;
					else cuad = 6;
				}
				else{
						if(col>=0 && col <= 2)
							cuad = 7;
						else if(col>=3 && col <= 5)
							cuad = 8;
						else cuad = 9;
				}
			}

			switch(cuad) //Botones son declarados , los subcuadrantes
			{
				case 1: x1=0; // columnas
						x2=2;
						y1=0; // renglones
						y2=2;
						break;
				case 2: x1=3; // columnas
						x2=5;
						y1=0; // renglones
						y2=2;
						break;
				case 3: x1=6; // columnas
						x2=8;
						y1=0; // renglones
						y2=2;
						break;
				case 4: x1=0; // columnas
						x2=2;
						y1=3; // renglones
						y2=5;
						break;
				case 5: x1=3; // columnas
						x2=5;
						y1=3; // renglones
						y2=5;
						break;
				case 6: x1=6; // columnas
						x2=8;
						y1=3; // renglones
						y2=5;
						break;
				case 7: x1=0; // columnas
						x2=2;
						y1=6; // renglones
						y2=8;
						break;
				case 8: x1=3; // columnas
						x2=5;
						y1=6; // renglones
						y2=8;
						break;
				case 9: x1=6; // columnas
						x2=8;
						y1=6; // renglones
						y2=8;
						break;
			}
			
				caux=0;
				
				for(i=x1;i<=x2;i++){ //columnas
					for(j=y1;j<=y2;j++) //renglones
					{
						if(matriz[j][i]==num){
							caux++;
							if(caux>1){
								salida = false; //Para revisar que no se repitan numeros.
							}
						}
					}
				}
				return salida;
		}

		public  void revisaArea(int ren, int col){
			int X,caux,i,j,k,cuad,x1,x2,y1,y2;
			
			x1=x2=y1=y2=0;
			
			if(ren >=0 && ren <=2)
			{
				if(col>=0 && col <= 2)
					cuad = 1;
				else if(col>=3 && col <= 5)
					cuad = 2;
				else cuad = 3;
			} else {
				if(ren >= 3 && ren <= 5)
				{
					if(col>=0 && col <= 2)
						cuad = 4;
					else if(col>=3 && col <= 5)
						cuad = 5;
					else cuad = 6;
				}
				else{
						if(col>=0 && col <= 2)
							cuad = 7;
						else if(col>=3 && col <= 5)
							cuad = 8;
						else cuad = 9;
				}
			}

			switch(cuad)
			{
				case 1: x1=0; // columnas
						x2=2;
						y1=0; // renglones
						y2=2;
						break;
				case 2: x1=3; // columnas
						x2=5;
						y1=0; // renglones
						y2=2;
						break;
				case 3: x1=6; // columnas
						x2=8;
						y1=0; // renglones
						y2=2;
						break;
				case 4: x1=0; // columnas
						x2=2;
						y1=3; // renglones
						y2=5;
						break;
				case 5: x1=3; // columnas
						x2=5;
						y1=3; // renglones
						y2=5;
						break;
				case 6: x1=6; // columnas
						x2=8;
						y1=3; // renglones
						y2=5;
						break;
				case 7: x1=0; // columnas
						x2=2;
						y1=6; // renglones
						y2=8;
						break;
				case 8: x1=3; // columnas
						x2=5;
						y1=6; // renglones
						y2=8;
						break;
				case 9: x1=6; // columnas
						x2=8;
						y1=6; // renglones
						y2=8;
						break;
			} //Lo mismo pero cuando los genero
			
			
			for(k=1;k<=9;k++) //
			{
				caux=0;
					
				for(i=x1;i<=x2;i++){ //columnas
					for(j=y1;j<=y2;j++) //renglones
					{
						if(matriz[j][i]==k){
							caux++;
							if(caux>1){
								System.out.println("dato repetido en area");
								X=(int)(Math.random()*8+1);
								System.out.println("Nuevo valor X "+X);
								matriz[j][i]=X;
								revisaFila(j);
								revisaColumna(i);
								revisaArea(j,i);
							}
						}
					}
				}
			}
			
		}
}

